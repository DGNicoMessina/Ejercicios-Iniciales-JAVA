/*
Realizar un programa en Java donde se creen dos arreglos: el primero será un arreglo A
de 50 números reales, y el segundo B, un arreglo de 20 números, también reales. El
programa deberá inicializar el arreglo A con números aleatorios y mostrarlo por pantalla.
Luego, el arreglo A se debe ordenar de menor a mayor y copiar los primeros 10 números
ordenados al arreglo B de 20 elementos, y rellenar los 10 últimos elementos con el valor
0.5. Mostrar los dos arreglos resultantes: el ordenado de 50 elementos y el combinado de
20.
*/


package poo_ej_10;

import java.util.Arrays;


public class POO_Ej_10 {

    public static void main(String[] args) {
    
        double[] vectorA = new double[50];
        double[] vectorB = new double[20];
        
        LlenarVector(vectorA);
        OrdenarVectorA(vectorA);
        RellenarVectorB(vectorA, vectorB);
        
    }
    
    public static void LlenarVector(double[] vector) {
        System.out.println("----El primer vector es: ----");
        for (int i = 0; i < vector.length; i++) {
            vector[i] = Math.random() * 10;
            System.out.println("|" + vector[i] + "|");
        }              
    }
    
    public static void OrdenarVectorA(double[] vectorA) {
        System.out.println("----El vector ordenado es: ----");
        Arrays.sort(vectorA);
        for (int i = 0; i < vectorA.length; i++) {
            System.out.println("|" + vectorA[i] + "|");
        }    
    }
    
    
    public static void RellenarVectorB(double[] vectorA, double[] vectorB) {
        System.out.println("----El vector B es: ----");
        Arrays.sort(vectorA);
        for (int i = 0; i < vectorB.length; i++) {
            if (i < 10) {
                vectorB[i] = vectorA[i];
            } else {
                vectorB[i] = 0.5;
            }
            System.out.println("|" + vectorB[i] + "|");
        }          
    }
   
    




}
    
package Servicio;

import java.util.Scanner;

import Entidad.Persona;

public class ServicioPersona {

    public Persona crearPersona() {

        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese el nombre: ");
        String nombre = leer.nextLine();
        System.out.println("Ingrese la edad: ");
        int edad = leer.nextInt();
        System.out.println("Ingrese el sexo ('H' hombre, 'M' mujer, 'O' otro): ");
        char sexo = leer.next().charAt(0);
        System.out.println("Ingrese el peso en kg: ");
        Double peso = leer.nextDouble();
        System.out.println("Ingrese la altura en metros: ");
        Double altura = leer.nextDouble();

        // Validar el sexo ingresado
        while (sexo != 'H' && sexo != 'M' && sexo != 'O') {
            System.out.println("Sexo inválido. Ingrese el sexo nuevamente ('H' hombre, 'M' mujer, 'O' otro): ");
            sexo = leer.next().charAt(0);

        }
        return new Persona(nombre, edad, sexo, peso, altura);

    }

    public int calcularImc(Persona p) {
        int aux;
        double imc = p.getPeso() / (p.getAltura() * p.getAltura());
        if (imc < 20) {
            aux= -1; // Por debajo del peso ideal
        } else if (imc >= 20 && imc <= 25) {
            aux = 0; // Peso ideal
        } else {
            aux=1; // Sobrepeso
        }
        return aux;
    }

    public boolean esMayorDeEdad(Persona p) {
        return p.getEdad() >= 18;
    }

}

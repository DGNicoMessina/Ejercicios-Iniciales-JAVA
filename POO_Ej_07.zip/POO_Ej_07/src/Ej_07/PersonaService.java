package Ej_07;

import Entidad.Persona;
import Servicio.ServicioPersona;

public class PersonaService {
       
    public static void main(String[] args) {

        ServicioPersona sp = new ServicioPersona();

        Persona[] personas = new Persona[4];


        
//        Persona persona2 = new Persona("Juan", 25, 'H', 75.5, 1.75);
//
//        Persona persona3 = new Persona();
//        persona3.setNombre("María");
//        persona3.setEdad(30);
//        persona3.setSexo('M');
//        persona3.setPeso(60.8);
//        persona3.setAltura(1.65);
//
//        Persona persona4 = new Persona("Pedro", 17, 'H', 68.2, 1.82);

        for(int i=0; i<4; i++) {
        personas[i]= sp.crearPersona();
        }
        
        int porDebajoPesoIdeal = 0;
        int pesoIdeal = 0;
        int sobrepeso = 0;

        int mayoresDeEdad = 0;
        int menoresDeEdad = 0;

        for (Persona persona : personas) {
            int imc = sp.calcularImc(persona);
            switch (imc) {
                case -1:
                    porDebajoPesoIdeal++;
                    break;
                case 0:
                    pesoIdeal++;
                    break;
                case 1:
                    sobrepeso++;
                    break;
            }

            if (sp.esMayorDeEdad(persona)) {
                mayoresDeEdad++;
            } else {
                menoresDeEdad++;
            }
        }

        double porcentajePorDebajoPesoIdeal = (porDebajoPesoIdeal * 100.0) / personas.length;
        double porcentajePesoIdeal = (pesoIdeal * 100.0) / personas.length;
        double porcentajeSobrepeso = (sobrepeso * 100.0) / personas.length;

        double porcentajeMayoresDeEdad = (mayoresDeEdad * 100.0) / personas.length;
        double porcentajeMenoresDeEdad = (menoresDeEdad * 100.0) / personas.length;

        System.out.println("Porcentaje de personas por debajo del peso ideal: " + porcentajePorDebajoPesoIdeal + "%");
        System.out.println("Porcentaje de personas en su peso ideal: " + porcentajePesoIdeal + "%");
        System.out.println("Porcentaje de personas con sobrepeso: " + porcentajeSobrepeso + "%");
        System.out.println("Porcentaje de personas mayores de edad: " + porcentajeMayoresDeEdad + "%");
        System.out.println("Porcentaje de personas menores de edad: " + porcentajeMenoresDeEdad + "%");
    }
}
            
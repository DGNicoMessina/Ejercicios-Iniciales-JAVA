/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entidad.Raices;

/**
 *
 * @author BrendaCalzada
 */
public class RaicesService {
    
    public double getDiscriminante(Raices raices){
        double a = raices.getA();
        double b = raices.getB();
        double c = raices.getC();
        return (b * b) - (4 * a * c);
    }
    
    public boolean tieneRaices(Raices raices) {
        double discriminante = getDiscriminante(raices);
        return discriminante >= 0;
    }
    
    public boolean tieneRaiz(Raices raices) {
        double discriminante = getDiscriminante(raices);
        return discriminante == 0;
    }
    
    public void obtenerRaices(Raices raices) {
        if (tieneRaices(raices)) {
            double discriminante = getDiscriminante(raices);
            double a = raices.getA();
            double b = raices.getB();
            double c = raices.getC();
            double raiz1 = (-b + Math.sqrt(discriminante)) / (2 * a);
            double raiz2 = (-b - Math.sqrt(discriminante)) / (2 * a);
            System.out.println("Raíz 1: " + raiz1);
            System.out.println("Raíz 2: " + raiz2);
        } else {
            System.out.println("No existen raíces reales.");
        }
    }
    
    public void obtenerRaiz(Raices raices) {
        if (tieneRaiz(raices)) {
            double b = raices.getB();
            double a = raices.getA();
            double raiz = -b / (2 * a);
            System.out.println("Raíz única: " + raiz);
        } else {
            System.out.println("No existe una única raíz real.");
        }
    }
}

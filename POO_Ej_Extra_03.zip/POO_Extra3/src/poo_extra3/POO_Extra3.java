

package poo_extra3;

import Entidad.Raices;
import Service.RaicesService;

/**
 *
 * @author BrendaCalzada
 */
public class POO_Extra3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Raices raices = new Raices(1, -3, 2);
        RaicesService raicesService = new RaicesService();

        double discriminante = raicesService.getDiscriminante(raices);
        boolean tieneRaices = raicesService.tieneRaices(raices);
        boolean tieneRaiz = raicesService.tieneRaiz(raices);

        if (tieneRaices) {
            raicesService.obtenerRaices(raices);
        } else if (tieneRaiz) {
            raicesService.obtenerRaiz(raices);
        } else {
            System.out.println("No existen soluciones reales para la ecuación.");
        }
    }
}


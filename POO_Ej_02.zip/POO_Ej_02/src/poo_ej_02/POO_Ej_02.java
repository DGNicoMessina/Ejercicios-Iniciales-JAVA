package poo_ej_02;

import Entidad.Circunferencia;
import Entidad.servicio.ServicioCircunferencia;

public class POO_Ej_02 {

    public static void main(String[] args) {

        ServicioCircunferencia radio = new ServicioCircunferencia();

        Circunferencia valor = radio.CreaCircunferencia();

        System.out.println(valor.toString());
        
        //Circunferencia Area = radio.Area();
        
        System.out.println("Area{area=" + radio.Area(valor)+"}");
        
        System.out.println("Perimetro{perimetro=" + radio.Perimetro(valor)+"}");
    }

}

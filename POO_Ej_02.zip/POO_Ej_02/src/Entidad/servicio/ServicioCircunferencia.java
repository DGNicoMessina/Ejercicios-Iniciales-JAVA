package Entidad.servicio;


import Entidad.Circunferencia;
import java.util.Scanner;


public class ServicioCircunferencia {
    
    Scanner leer = new Scanner(System.in);
    
    public Circunferencia CreaCircunferencia (){
        System.out.println("Ingrese el radio, por favor");
        double radio = leer.nextDouble();
        return new Circunferencia(radio);
    }
    
    public double Area (Circunferencia r1){
        double radio = r1.getRadio();
        double π = 3.1416;
        return ((radio*radio)*π);
    }
    
    public double Perimetro (Circunferencia r1){
        double radio = r1.getRadio();
        double π = 3.1416;
        return (2*radio*π);
    }
    
}


//(Area = π * radio2)
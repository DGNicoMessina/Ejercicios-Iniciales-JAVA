
package OperacionServicio;

public class OperacionMain{

    public static void main(String[] args) {
     
        Operacion operacion1 = new Operacion(); // Se crea un objeto utilizando el constructor sin parámetros
        operacion1.crearOperacion(); // Se solicitan los números al usuario
        
        Operacion operacion2 = new Operacion(5, 10); // Se crea un objeto utilizando el constructor con parámetros
        
        // Obtener los números utilizando los métodos get
        int numero1 = operacion1.getNumero1();
        int numero2 = operacion1.getNumero2();
        int resultadoSuma = operacion1.sumar();
        int resultadoResta = operacion1.restar();
        int resultadoMultiplicacion = operacion1.multiplicar();
        double resultadoDivision = operacion1.dividir();
        
        
        // Imprimir los números ingresados
        System.out.println("Número 1: " + numero1);
        System.out.println("Número 2: " + numero2);
        System.out.println("Suma: " + resultadoSuma);
        System.out.println("Resta: " + resultadoResta);
        System.out.println("Multiplicación: " + resultadoMultiplicacion);
        System.out.println("División: " + resultadoDivision);
    
    
    
    }
    
    
}






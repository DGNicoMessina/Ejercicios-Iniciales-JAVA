package ejercicio12.service;

import ejercicio12.entity.Persona;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class ServicePersona {

	private Persona persona; // Variable de clase para almacenar la persona


	/**
	 * Metodo crearPersona que crea una nueva instancia de Persona y la asigna a la variable de clase
	 * @return
	 */
	public Persona crearPersona() {

		Scanner scanner = new Scanner(System.in);
		Persona nuevaPersona = new Persona(); // Crear una nueva instancia de Persona

		System.out.print("Ingrese el nombre de la persona: ");
		String nombre = scanner.nextLine();
		nuevaPersona.setNombre(nombre); // Establecer el nombre de la nueva persona

		System.out.print("Ingrese la fecha de nacimiento (en formato dd/mm/aaaa): ");
		String fechaStr = scanner.nextLine();//Obtener la fecha de nacimiento como una cadena de texto


		/**
		 * El try catch se utiliza para capturar una excepción en caso de que ocurra
		 * Si ocurre una excepción, se asigna la fecha actual a la persona
		 * Si no ocurre una excepción, se asigna la fecha ingresada a la persona
		 * @SimpleDateFormat es una clase que permite formatear y analizar fechas
		 * @parse() es un método de la clase SimpleDateFormat que permite convertir una cadena de texto en una fecha
		 * @format() es un método de la clase SimpleDateFormat que permite convertir una fecha en una cadena de texto
		 * @Date es una clase que representa una fecha
		 */
		try {
			SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");//Aqui se establece el formato de la fecha
			Date fechaNacimiento = formatoFecha.parse(fechaStr);//Aqui se convierte la cadena de texto en una fecha utilizando el formato establecido
			nuevaPersona.setFechaNacimiento(fechaNacimiento); // Establecer la fecha de nacimiento de la nueva persona
		} catch (ParseException e) {
			System.out.println("Error al parsear la fecha. Se asignará la fecha actual.");//Si hay un error al parsear la fecha, se asigna la fecha actual
			nuevaPersona.setFechaNacimiento(new Date()); // Si hay un error al parsear la fecha, se asigna la fecha actual
		}

		persona = nuevaPersona; // Asignar la persona creada a la variable de clase
		return persona;//Retornar la persona creada
	}


	/**
	 * Metodo calcularEdad que calcula la edad de la persona almacenada en la variable de clase persona
	 * @return
	 */
	public int calcularEdad() {
		if (persona == null) {
			System.out.println("No se ha creado ninguna persona.");
			return 0;
		}

		Date fechaNacimiento = persona.getFechaNacimiento(); // Obtener la fecha de nacimiento de la persona
		Date fechaActual = new Date(); // Obtener la fecha actual
		Calendar calFechaNacimiento = Calendar.getInstance();
		calFechaNacimiento.setTime(fechaNacimiento); // Configurar el calendario con la fecha de nacimiento
		Calendar calFechaActual = Calendar.getInstance();
		calFechaActual.setTime(fechaActual); // Configurar el calendario con la fecha actual

		// Calcular la diferencia de años entre la fecha actual y la fecha de nacimiento
		int edad = calFechaActual.get(Calendar.YEAR) - calFechaNacimiento.get(Calendar.YEAR);


		/**
		 * Comprobar si el mes de nacimiento es posterior al mes actual,
		 * o si el mes de nacimiento es el mismo pero el día de nacimiento es posterior
		 * @MONTH es un campo estático de la clase Calendar
		 * @DAY_OF_MONTH es un campo estático de la clase Calendar que sirve para obtener el día del mes
		 * el if se ejecuta si el mes de nacimiento es posterior al mes actual o si el mes de nacimiento es el mismo
		 * pero el día de nacimiento es posterior
		 */
		if (calFechaActual.get(Calendar.MONTH) < calFechaNacimiento.get(Calendar.MONTH)//Si el mes de nacimiento es posterior al mes actual o si el mes de nacimiento es el mismo pero el día de nacimiento es posterior
			 || (calFechaActual.get(Calendar.MONTH) == calFechaNacimiento.get(Calendar.MONTH)//Si el mes de nacimiento es el mismo pero el día de nacimiento es posterior
				  && calFechaActual.get(Calendar.DAY_OF_MONTH) < calFechaNacimiento.get(Calendar.DAY_OF_MONTH))) {
			edad--; // Restar 1 a la edad si la fecha de nacimiento es posterior a la fecha actual
		}

		return edad; // Devolver la edad calculada
	}


	/**
	 * Metodo mayorQue que comprueba si la edad de la persona es mayor que el valor dado
	 * @param edad
	 * @return
	 */
	public boolean menorQue(int edad) {
		int edadPersona = calcularEdad(); // Obtener la edad de la persona
		return edadPersona < edad; // Comprobar si la edad de la persona es menor que el valor dado
	}


	/**
	 * Metodo mostrarPersona que muestra los datos de la persona almacenada en la variable de clase persona
	 * Si no se ha creado ninguna persona, se muestra un mensaje de error
	 */
	public void mostrarPersona() {
		if (persona == null) {
			System.out.println("No se ha creado ninguna persona.");
			return;
		}
		System.out.println("Nombre: " + persona.getNombre());
		System.out.println("Fecha de nacimiento: " + persona.getFechaNacimiento());
		System.out.println("Edad: " + calcularEdad() + " años");
	}
}

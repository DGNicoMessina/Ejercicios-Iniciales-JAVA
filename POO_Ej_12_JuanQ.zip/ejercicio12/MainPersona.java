package ejercicio12;

import ejercicio12.entity.Persona;
import ejercicio12.service.ServicePersona;


public class MainPersona {

	public static void main(String[] args) {

		ServicePersona personaService = new ServicePersona(); // Crear una instancia de ServicePersona

		Persona persona = personaService.crearPersona(); // Crear una nueva persona utilizando el servicio
		personaService.mostrarPersona(); // Mostrar los detalles de la persona creada

		int edadLimite = 18; // Establecer una edad límite
		if (personaService.menorQue(edadLimite)) { // Comprobar si la persona es menor que la edad límite
			System.out.println("La persona es menor que " + edadLimite + " años.");
		} else {
			System.out.println("La persona no es menor que " + edadLimite + " años.");
		}

	}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio9;

import Entidad.Matematica;
import Servicio.ServicioMatematica;

/**
 *
 * @author Evocuer
 */
public class EJ9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        double[] num = new double[2];
        
        ServicioMatematica sm = new ServicioMatematica();
        Matematica m = sm.crearMatematica();
       
        num = sm.devolverMayor(m);
        
    }
    
}

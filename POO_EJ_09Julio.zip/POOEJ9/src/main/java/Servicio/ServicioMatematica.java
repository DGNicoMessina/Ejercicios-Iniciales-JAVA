/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import java.util.Scanner;

import Entidad.Matematica;

/**
 *
 * @author Evocuer
 */
public class ServicioMatematica {
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public Matematica crearMatematica() {
        
        Matematica m = new Matematica();
        
        m.setNumero1(10*Math.random());
        m.setNumero2(10*Math.random());
        
    return m;
    }
    
    public double[] devolverMayor(Matematica m) {
        
        double[] num = new double[2];
        
        if (m.getNumero1() > m.getNumero2()) {
            System.out.println("El numero mayor es el numero 1");
            num[0] = m.getNumero1(); 
            num[1] = m.getNumero2();
        }else if (m.getNumero2() > m.getNumero1()) {
            System.out.println("El numero mayor es el numero 2");
            num[1] = m.getNumero1(); 
            num[0] = m.getNumero2();
        } else {
            System.out.println("los numeros son iguales");  
        }
        return num;
    }
    
    public void calcularPotencia(Matematica m, double[] num) {
                
        System.out.println(Math.pow(Math.round(num[0]), Math.round(num[1])));
        
    }
    
    public void calcularPotencia(Matematica m, double[] num) {
        
        System.out.println(Math.sqrt(Math.abs(num[1])));
        
    }
    
}

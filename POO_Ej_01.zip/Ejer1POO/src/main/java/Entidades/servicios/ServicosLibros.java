/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades.servicios;

import Entidad.Libro;
import java.util.Scanner;

/**
 *
 * @author Mafe
 */
public class ServicosLibros {
    
    public Libro crearLibro(){
        Scanner leer = new Scanner(System.in);
        
        System.out.println("Ingresar ISBN");
        String ISBN = leer.nextLine();
         System.out.println("Ingresar autor");
        String autor = leer.nextLine();
         System.out.println("Ingresar titulo");
        String titulo = leer.nextLine();
         System.out.println("Ingresar Nurmos de pagina");
        int numeroDePagina = leer.nextInt();
        
       return new Libro(numeroDePagina, titulo, autor, numeroDePagina);
    }
    
    
    
}

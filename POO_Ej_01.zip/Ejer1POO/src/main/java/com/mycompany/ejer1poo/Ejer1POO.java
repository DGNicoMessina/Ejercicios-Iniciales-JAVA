/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejer1poo;

import Entidad.Libro;
import Entidades.servicios.ServicosLibros;

/**
 *
 * @author Mafe
 */
public class Ejer1POO {

    public static void main(String[] args) {
      
        ServicosLibros L1 = new ServicosLibros();
        
        Libro libro1 = L1.crearLibro();
        
        System.out.println(libro1.toString());
        
        
    }
}

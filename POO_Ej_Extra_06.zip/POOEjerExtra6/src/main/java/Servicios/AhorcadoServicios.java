/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidad.ahorcado;
import java.util.Scanner;

/**
 *
 * @author Mafe
 */
public class AhorcadoServicios {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public ahorcado crearJuego() {

        ahorcado A = new ahorcado();

        System.out.println("Ingresa la palabra ");
        String palabra = leer.nextLine();

        int longPalabra = palabra.length();

        String[] Pal = new String[longPalabra];

        System.out.println("Cantidad de intentos");
        int vidas = leer.nextInt();
        A.setVidas(vidas);

        for (int i = 0; i < Pal.length; i++) {

            Pal[i] = palabra.substring(i, i + 1);
            System.out.println(Pal[i]);

        }

        A.setPalabra(Pal);

        return A;

    }

    public void longitud(ahorcado A) {

        System.out.println(" La palabra tiene " + A.getPalabra().length + " letras");

    }

    public boolean buscar(String A, ahorcado B) {

        boolean tes = false;

        for (int i = 0; i < B.getPalabra().length; i++) {

            if (B.getPalabra()[i].equalsIgnoreCase(A)) {

                System.out.println("La letra esta en la posicion " + (i + 1));
                tes = true;
            }
        }

        if (!tes) {
            System.out.println("La letra no esta");
        }

        return tes;

    }

    public void encontradas(String A, ahorcado B, boolean tes) {

        if (tes) {
            int con = B.getLetrasEncontradas();
            B.setLetrasEncontradas(con + 1);
        }
        System.out.println("La letras encontradas son: " + B.getLetrasEncontradas());
        System.out.println(" Las letras que te faltan son: " + (B.getPalabra().length - B.getLetrasEncontradas()));

    }

    public void intentos(String A, ahorcado B, boolean tes) {

        if (!tes) {
            int vidas = B.getVidas();
            B.setVidas(vidas - 1);

        }

        System.out.println("Te quedan " + B.getVidas() + " vidas");

    }

    public void juego() {

        ahorcado A = crearJuego();

        longitud(A);

        leer.nextLine();

        do {
            System.out.println("Ingresa una letra");

            String letra = leer.nextLine();
            boolean tes = buscar(letra, A);
            encontradas(letra, A, tes);
            intentos(letra, A, tes);

            if (A.getLetrasEncontradas() >= A.getPalabra().length) {
                System.out.println("Ganamos");
                break;
            }
            if (A.getVidas() == 0) {
                System.out.println("Perdimos");

            }

        } while (A.getVidas() > 0);
        
         System.out.println("Igual nos divetimos :)");

    }

}

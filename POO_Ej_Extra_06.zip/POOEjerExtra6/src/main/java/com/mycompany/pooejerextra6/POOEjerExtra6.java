/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pooejerextra6;

import Entidad.ahorcado;
import Servicios.AhorcadoServicios;

/**
 *
 * @author Mafe
 */
public class POOEjerExtra6 {

    public static void main(String[] args) {
        
    AhorcadoServicios AS = new AhorcadoServicios();
    
    
    AS.juego();
    }
}

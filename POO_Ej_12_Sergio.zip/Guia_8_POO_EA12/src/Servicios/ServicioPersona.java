/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Persona;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Sergio Jurado
 */
public class ServicioPersona {
    
    Scanner leer = new Scanner(System.in);
    
    public Persona crearPersona(){
        
        Persona per = new Persona();
        
        System.out.println("Por fvor, ingrese el nombre de la persona");
        per.setNombre(leer.next());
        System.out.println("Por favor, ingrese el año de nacimiento");
        int anio = leer.nextInt();
        System.out.println("Por favor, ingrese el mes de nacimiento");
        int mes = leer.nextInt();
        System.out.println("Por favor, ingrese el día de nacimiento");
        int dia = leer.nextInt();
        
        Date nac = new Date((anio-1900),(mes-1),dia);
        
        per.setFechaNac(nac);
        
        return per;
                
    }
    
    public int calcularEdad(Persona per){
        
        Date fechaActual = new Date();
        
        int anioActual = fechaActual.getYear() + 1900;
        int anioNac = per.getFechaNac().getYear() + 1900;
        
        int edad = anioActual - anioNac;
        
        return edad;
        
    }

    public boolean menorQue(int anios, int edad){
        
        boolean menorMayor;
        
        if (edad > anios) {
            menorMayor = true;
        } else {
            menorMayor = false;
        }
        
        return menorMayor;
        
    }
    
    public void mostrarPersona(Persona per, int edad){
        
        System.out.println("La persona ingresada se llama, " + per.getNombre() + ", y su fecha de nacimiento es: " + per.getFechaNac() + " y su edad es " + edad);
        
    }
    
}

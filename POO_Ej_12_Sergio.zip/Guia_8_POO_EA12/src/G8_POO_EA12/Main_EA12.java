/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package G8_POO_EA12;

import Entidades.Persona;
import Servicios.ServicioPersona;
import java.util.Scanner;

/**
 *
 * @author Sergio Jurado
 */
public class Main_EA12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona per = new Persona();
        ServicioPersona sp = new ServicioPersona();
        
        Scanner leer = new Scanner(System.in);
        
        per = sp.crearPersona();
        
        int edadP1 = sp.calcularEdad(per);
        
        System.out.println("Por favor, ingrese una edad cualquiera");
        int edadP2 = leer.nextInt();
        boolean menorMayor = sp.menorQue(edadP1, edadP2);
        
        if (menorMayor == true) {
            System.out.println("La persona es menor que la segunda edad ingresada");
        } else {
            System.out.println("La persona es mayor que la segunda edad ingresada");
        }
        
        sp.mostrarPersona(per, edadP1);
        
    }
    
}

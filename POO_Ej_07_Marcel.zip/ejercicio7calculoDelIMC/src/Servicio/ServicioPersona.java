/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;
//esta es la interaccion para jalar info de la clase persona

import Entidades.Persona;
//esto te permite ingresar info por teclado
import java.util.Scanner;

/**
 *
 * @author QUIERO MAS
 */
public class ServicioPersona {

    private Scanner leer = new Scanner(System.in).useDelimiter("\n");
//metodo para crear persona

    public Persona crearPersona() {

        Persona p = new Persona();
        System.out.println("Ingrese el nombre de la persona:");
        p.setNombre(leer.next());
        System.out.println("Ingrese la edad de la persona:");
        p.setEdad(leer.nextInt());
        System.out.println("Ingrese el sexo de la persona");
        p.setSexo(leer.next());
        System.out.println("Ingrese el peso de la persona");
        p.setPeso(leer.nextDouble());
        System.out.println("Ingrese la altura de la persona");
        p.setAltura(leer.nextDouble());

        return p;
    }
//metodo para calcular indice de masa corporal
        
    public int IndiceDeMasaCorporal(Persona persona) {
        double imc;
        imc = persona.getPeso() / Math.pow(persona.getAltura(), 2);
        if (imc < 20) {
            //System.out.println("-1");
            
            return -1;

        } else if ((imc >= 20) & (imc <= 25)) {
            //System.out.println("0");
            
            return 0;

        } else {
            //System.out.println("1");
            
            return 1;

        }
    }

    public boolean MayoriaDeEdad(Persona persona) {
        if (persona.getEdad() > 18) {
            //System.out.println("Es mayor de edad");
            return true;
            
            
        } else {
            //System.out.println("Es menor de edad");
           return false;
        }
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio7calculodelimc;

import Entidades.Persona;
import Servicio.ServicioPersona;

/**
 *
 * @author QUIERO MAS
 */
public class Ejercicio7calculoDelIMC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //con esta codigo se crea el objete, se instancia para traer los metodos de la clase servicio
        
        double pb =0 ;
        double pok =0;
        double pa =0;
        double ma=0;
        double me=0;
        
        double xpb =0;
        double xpok =0;
        double xpa =0;
        double xma=0;
        double xme=0;
         
        
        ServicioPersona servicioPersona = new ServicioPersona();
        //ya creado el objeto se debe guardar en una variable  utilizando el metodo de la clase servicio
        Persona P1 = servicioPersona.crearPersona();
        System.out.println(P1);
        servicioPersona.IndiceDeMasaCorporal(P1);
        servicioPersona.MayoriaDeEdad(P1);
        if (servicioPersona.IndiceDeMasaCorporal(P1)==-1) {
            pb++;
        }else if (servicioPersona.IndiceDeMasaCorporal(P1)==0) {
            pok++;  
        }else {
            pa++;
        }
        if (servicioPersona.MayoriaDeEdad(P1)==true) {
            ma++;  
        }else{
           me++; 
        }
        
        Persona P2 = servicioPersona.crearPersona();
        System.out.println(P2);
        servicioPersona.IndiceDeMasaCorporal(P2);
        servicioPersona.MayoriaDeEdad(P2);
        if (servicioPersona.IndiceDeMasaCorporal(P2)==-1) {
            pb++;
            
        }else if (servicioPersona.IndiceDeMasaCorporal(P2)==0) {
            pok++;  
        }else {
            pa++;
        }
        System.out.println("");
         if (servicioPersona.MayoriaDeEdad(P2)==true) {
            ma++;  
        }else{
           me++; 
        }
        
        
        Persona P3 = servicioPersona.crearPersona();
        System.out.println(P3);
        servicioPersona.IndiceDeMasaCorporal(P3);
        servicioPersona.MayoriaDeEdad(P3);
        if (servicioPersona.IndiceDeMasaCorporal(P3)==-1) {
            pb++;
        }else if (servicioPersona.IndiceDeMasaCorporal(P3)==0) {
            pok++;  
        }else {
            pa++;
        }
         if (servicioPersona.MayoriaDeEdad(P3)==true) {
            ma++;  
        }else{
           me++; 
        }
        
      
        
        Persona P4 = servicioPersona.crearPersona();
        System.out.println(P4);
        servicioPersona.IndiceDeMasaCorporal(P4);
        servicioPersona.MayoriaDeEdad(P4);
       if (servicioPersona.IndiceDeMasaCorporal(P4)==-1) {
            pb++;
        }else if (servicioPersona.IndiceDeMasaCorporal(P4)==0) {
            pok++;  
        }else {
            pa++;
        }
        if (servicioPersona.MayoriaDeEdad(P4)==true) {
            ma++;  
        }else{
           me++; 
        }
        
        
    xpb=(pb/4)*100;
    xpok=(pok/4)*100;
    xpa=(pa/4)*100;
    
    xme=(me/4)*100;
    xma=(ma/4)*100;
            
        System.out.println("El porcentaje de personas con bajo peso es: "+xpb);
        System.out.println("El porcentaje de personas con peso ok  es: "+xpok);
        System.out.println("El porcentaje de personas con alto peso es: "+xpa);
        System.out.println("El porcentaje de personas menores de edad es: "+xme);
        System.out.println("El porcentaje de personas mayores de edas es:"+xma);
      
    }
    
}
